//
//  BaseModel.m
//  BaseProject
//
//  Created by 王杰 on 15/11/7.
//  Copyright © 2015年 wangjie. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel

MJCodingImplementation

@end

