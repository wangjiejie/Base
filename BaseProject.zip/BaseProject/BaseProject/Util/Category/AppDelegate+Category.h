//
//  AppDelegate+Category.h
//  BaseProject
//
//  Created by 王杰 on 15/11/7.
//  Copyright © 2015年 wangjie. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Category)

- (void)initializeWithApplication:(UIApplication *)application;

@end
